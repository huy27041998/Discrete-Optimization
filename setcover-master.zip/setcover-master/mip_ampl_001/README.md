setcover
========
Simple MIP model for Set Cover Problem. Tested on Windows x86. To run solver.py you need copy to subfolder ./ampl/ your AMPL, Gurobi and CPLEX
solvers.

P.S. Also you can change time limit for CPLEX and Gurobi solvers to get better solution.