setcover
========

Open source solvers for the Discrete Optimization set cover assignment.

The root directory includes the set cover handout.  Subdirectories include various solver examples for the set cover problem.  To try one of the solvers simply follow any build and installation instructions and run the solver.py file in that directory.

This base repository will be maintained by the Discrete Optimization course staff.  Students are encouraged to fork this repository to share their solutions to this assignment.
