cp solver using ortools for setcover problem
==================
The MIT License (MIT)

&copy; 2019 Qi Wang

* This `solver.py` solves the problem using Constraint Programming Solvers - ortools, which is an open library and provide Python apis
* Install ortools, for Python 2.7 or 3.5+ installed, simply run the following command in your shell terminal:
* `python -m pip install --upgrade --user ortools`
* About ortools: see https://developers.google.com/optimization/
